import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../providers/transaction_provider.dart';
import '../providers/category_provider.dart';
import '../utils/theme.dart';
import 'dart:math'; // For demo purposes

class AiAssistantScreen extends StatefulWidget {
  const AiAssistantScreen({Key? key}) : super(key: key);

  @override
  State<AiAssistantScreen> createState() => _AiAssistantScreenState();
}

class _AiAssistantScreenState extends State<AiAssistantScreen> {
  bool _isLoading = false;
  String _selectedFeature = 'spending';
  final TextEditingController _questionController = TextEditingController();

  @override
  void dispose() {
    _questionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Text(
            'AI Assistant',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
              color: primaryColor,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Powered by Gemini',
            style: TextStyle(
              color: secondaryColor,
              fontStyle: FontStyle.italic,
            ),
          ),
          const SizedBox(height: 24),

          // Feature Selection
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                _buildFeatureButton(
                  'spending',
                  'Spending Analysis',
                  Icons.analytics,
                ),
                _buildFeatureButton(
                  'budget',
                  'Budget Suggestions',
                  Icons.account_balance_wallet,
                ),
                _buildFeatureButton(
                  'insights',
                  'Automatic Insights',
                  Icons.lightbulb_outline,
                ),
                _buildFeatureButton(
                  'stocks',
                  'Stock Recommendations',
                  Icons.trending_up,
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          // Feature Content
          Expanded(
            child: _isLoading ? _buildLoadingState() : _buildFeatureContent(),
          ),

          // Ask AI Section
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: backgroundColor,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Ask AI Assistant',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: primaryColor,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _questionController,
                        decoration: InputDecoration(
                          hintText: 'Ask anything about your finances...',
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 12,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    ElevatedButton(
                      onPressed: () {
                        if (_questionController.text.isNotEmpty) {
                          setState(() {
                            _isLoading = true;
                          });

                          // Simulate AI processing
                          Future.delayed(const Duration(seconds: 2), () {
                            setState(() {
                              _isLoading = false;
                              // In a real app, we would process the question here
                              _questionController.clear();
                            });

                            _showAIResponse(context);
                          });
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        shape: const CircleBorder(),
                        padding: const EdgeInsets.all(12),
                        backgroundColor: accentColor,
                      ),
                      child: const Icon(Icons.send),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFeatureButton(String feature, String label, IconData icon) {
    final isSelected = _selectedFeature == feature;

    return Padding(
      padding: const EdgeInsets.only(right: 12),
      child: ElevatedButton.icon(
        onPressed: () {
          setState(() {
            _selectedFeature = feature;
            _isLoading = true;
          });

          // Simulate loading
          Future.delayed(const Duration(seconds: 1), () {
            setState(() {
              _isLoading = false;
            });
          });
        },
        icon: Icon(icon),
        label: Text(label),
        style: ElevatedButton.styleFrom(
          backgroundColor: isSelected ? primaryColor : Colors.white,
          foregroundColor: isSelected ? Colors.white : primaryColor,
          elevation: isSelected ? 4 : 1,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: BorderSide(
              color:
                  isSelected
                      ? Colors.transparent
                      : primaryColor.withOpacity(0.3),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const CircularProgressIndicator(),
          const SizedBox(height: 16),
          Text(
            'AI is analyzing your data...',
            style: TextStyle(
              color: secondaryColor,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFeatureContent() {
    switch (_selectedFeature) {
      case 'spending':
        return _buildSpendingAnalysis();
      case 'budget':
        return _buildBudgetSuggestions();
      case 'insights':
        return _buildAutomaticInsights();
      case 'stocks':
        return _buildStockRecommendations();
      default:
        return const Center(child: Text('Select a feature'));
    }
  }

  Widget _buildSpendingAnalysis() {
    final transactionProvider = Provider.of<TransactionProvider>(context);
    final categoryProvider = Provider.of<CategoryProvider>(context);

    // Get current week's start and end dates
    final now = DateTime.now();
    final startOfWeek = now.subtract(Duration(days: now.weekday - 1));
    final endOfWeek = startOfWeek.add(const Duration(days: 6));

    // Get transactions for this week
    final weekTransactions =
        transactionProvider.transactions
            .where(
              (tx) =>
                  tx.date.isAfter(startOfWeek) &&
                  tx.date.isBefore(endOfWeek.add(const Duration(days: 1))) &&
                  tx.type == TransactionType.expense,
            )
            .toList();

    // Group by category
    final expensesByCategory = <String, double>{};
    for (final tx in weekTransactions) {
      expensesByCategory.update(
        tx.categoryId,
        (value) => value + tx.amount,
        ifAbsent: () => tx.amount,
      );
    }

    // Find highest spending category
    String? highestCategoryId;
    double highestAmount = 0;

    expensesByCategory.forEach((categoryId, amount) {
      if (amount > highestAmount) {
        highestAmount = amount;
        highestCategoryId = categoryId;
      }
    });

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [primaryColor, secondaryColor],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.analytics, color: Colors.white),
                    const SizedBox(width: 8),
                    Text(
                      'This Week\'s Spending Analysis',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                if (highestCategoryId != null) ...[
                  Text(
                    'Your highest spending category this week is:',
                    style: const TextStyle(color: Colors.white70),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Icon(
                          categoryProvider
                                  .getCategoryById(highestCategoryId!)
                                  ?.icon ??
                              Icons.category,
                          color: Colors.white,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            categoryProvider
                                    .getCategoryById(highestCategoryId!)
                                    ?.name ??
                                'Unknown',
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 18,
                            ),
                          ),
                          Text(
                            NumberFormat.currency(
                              locale: 'id',
                              symbol: 'Rp ',
                              decimalDigits: 0,
                            ).format(highestAmount),
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ] else ...[
                  const Text(
                    'No expenses recorded for this week.',
                    style: TextStyle(color: Colors.white),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 24),
          Text(
            'Weekly Category Breakdown',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: secondaryColor,
              fontSize: 16,
            ),
          ),
          const SizedBox(height: 16),
          if (expensesByCategory.isNotEmpty) ...[
            ...expensesByCategory.entries.map((entry) {
              final category = categoryProvider.getCategoryById(entry.key);
              final percentage =
                  (entry.value /
                      expensesByCategory.values.reduce((a, b) => a + b)) *
                  100;

              return Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(
                          category?.icon ?? Icons.category,
                          color: category?.color ?? Colors.grey,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          category?.name ?? 'Unknown',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        const Spacer(),
                        Text(
                          NumberFormat.currency(
                            locale: 'id',
                            symbol: 'Rp ',
                            decimalDigits: 0,
                          ).format(entry.value),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    LinearProgressIndicator(
                      value: percentage / 100,
                      backgroundColor: Colors.grey.shade200,
                      valueColor: AlwaysStoppedAnimation<Color>(
                        category?.color ?? accentColor,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${percentage.toStringAsFixed(1)}%',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey.shade600,
                      ),
                    ),
                  ],
                ),
              );
            }).toList(),
          ] else ...[
            Center(
              child: Padding(
                padding: const EdgeInsets.all(24.0),
                child: Text(
                  'No expenses recorded for this week.',
                  style: TextStyle(color: Colors.grey.shade600),
                ),
              ),
            ),
          ],
          const SizedBox(height: 16),
          if (expensesByCategory.isNotEmpty) ...[
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: backgroundColor,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: accentColor.withOpacity(0.3)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.lightbulb, color: accentColor),
                      const SizedBox(width: 8),
                      Text(
                        'AI Insight',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: primaryColor,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    highestCategoryId != null
                        ? 'You\'ve spent ${NumberFormat.currency(locale: 'id', symbol: 'Rp ', decimalDigits: 0).format(highestAmount)} on ${categoryProvider.getCategoryById(highestCategoryId!)?.name ?? 'Unknown'} this week. This is ${Random().nextInt(30) + 10}% higher than your usual spending in this category.'
                        : 'No significant spending patterns detected this week.',
                    style: const TextStyle(fontSize: 14),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildBudgetSuggestions() {
    final transactionProvider = Provider.of<TransactionProvider>(context);
    final categoryProvider = Provider.of<CategoryProvider>(context);

    // Get last month's expenses
    final now = DateTime.now();
    final lastMonth = DateTime(now.year, now.month - 1);

    final lastMonthExpenses =
        transactionProvider
            .getTransactionsByMonth(lastMonth.year, lastMonth.month)
            .where((tx) => tx.type == TransactionType.expense)
            .toList();

    // Group by category
    final expensesByCategory = <String, double>{};
    for (final tx in lastMonthExpenses) {
      expensesByCategory.update(
        tx.categoryId,
        (value) => value + tx.amount,
        ifAbsent: () => tx.amount,
      );
    }

    // Calculate total income for last month
    final lastMonthIncome = transactionProvider.getTotalIncomeByMonth(
      lastMonth.year,
      lastMonth.month,
    );

    // Calculate suggested budget (for demo purposes)
    final suggestedBudgets = <String, double>{};
    final totalExpenses = expensesByCategory.values.fold<double>(
      0,
      (sum, amount) => sum + amount,
    );

    if (totalExpenses > 0 && lastMonthIncome > 0) {
      expensesByCategory.forEach((categoryId, amount) {
        // Suggest slightly less than what was spent last month
        suggestedBudgets[categoryId] = amount * 0.9;
      });
    }

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [secondaryColor, accentColor],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(
                      Icons.account_balance_wallet,
                      color: Colors.white,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'Suggested Budget for ${DateFormat.yMMMM().format(now)}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                if (suggestedBudgets.isNotEmpty) ...[
                  Text(
                    'Based on your spending patterns, here\'s an ideal budget:',
                    style: const TextStyle(color: Colors.white70),
                  ),
                ] else ...[
                  const Text(
                    'Not enough data to suggest a budget. Add more transactions.',
                    style: TextStyle(color: Colors.white),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 24),

          if (suggestedBudgets.isNotEmpty) ...[
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: suggestedBudgets.length,
              itemBuilder: (context, index) {
                final entry = suggestedBudgets.entries.elementAt(index);
                final category = categoryProvider.getCategoryById(entry.key);

                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: (category?.color ?? Colors.grey).withOpacity(
                              0.2,
                            ),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            category?.icon ?? Icons.category,
                            color: category?.color ?? Colors.grey,
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                category?.name ?? 'Unknown',
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Row(
                                children: [
                                  Text(
                                    'Last month: ',
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: Colors.grey.shade600,
                                    ),
                                  ),
                                  Text(
                                    NumberFormat.currency(
                                      locale: 'id',
                                      symbol: 'Rp ',
                                      decimalDigits: 0,
                                    ).format(expensesByCategory[entry.key]),
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: Colors.grey.shade600,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              NumberFormat.currency(
                                locale: 'id',
                                symbol: 'Rp ',
                                decimalDigits: 0,
                              ).format(entry.value),
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: primaryColor,
                                fontSize: 16,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'Suggested',
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.grey.shade600,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: backgroundColor,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: accentColor.withOpacity(0.3)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.lightbulb, color: accentColor),
                      const SizedBox(width: 8),
                      Text(
                        'AI Insight',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: primaryColor,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Following this budget could help you save approximately 10% of your monthly expenses. Consider setting up automatic transfers to a savings account.',
                    style: TextStyle(fontSize: 14),
                  ),
                ],
              ),
            ),
          ] else ...[
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.account_balance_wallet_outlined,
                    size: 64,
                    color: Colors.grey.shade300,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Not enough data to suggest a budget',
                    style: TextStyle(color: Colors.grey.shade600, fontSize: 16),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Add more transactions to get personalized budget suggestions',
                    style: TextStyle(color: Colors.grey.shade500, fontSize: 14),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildAutomaticInsights() {
    final transactionProvider = Provider.of<TransactionProvider>(context);
    final categoryProvider = Provider.of<CategoryProvider>(context);

    // Get current month's data
    final now = DateTime.now();
    final currentMonthExpenses =
        transactionProvider
            .getTransactionsByMonth(now.year, now.month)
            .where((tx) => tx.type == TransactionType.expense)
            .toList();

    // Generate some mock insights
    final insights = <Map<String, dynamic>>[];

    // Group expenses by category
    final expensesByCategory = <String, double>{};
    for (final tx in currentMonthExpenses) {
      expensesByCategory.update(
        tx.categoryId,
        (value) => value + tx.amount,
        ifAbsent: () => tx.amount,
      );
    }

    // Generate insights based on spending patterns
    expensesByCategory.forEach((categoryId, amount) {
      try {
        final category = categoryProvider.getCategoryById(categoryId);

        // Mock budget percentages
        final percentage = Random().nextInt(30) + 50; // Between 50% and 80%

        insights.add({
          'category': category,
          'amount': amount,
          'percentage': percentage,
          'type': 'budget',
        });
      } catch (e) {
        // Category not found
      }
    });

    // Add some additional insights
    if (insights.isNotEmpty) {
      insights.add({
        'type': 'saving',
        'message':
            'You could save ${NumberFormat.currency(locale: 'id', symbol: 'Rp ', decimalDigits: 0).format(Random().nextInt(500000) + 100000)} by reducing your ${insights.first['category'].name} expenses.',
      });

      insights.add({
        'type': 'trend',
        'message':
            'Your spending on ${insights.last['category'].name} has ${Random().nextBool() ? 'increased' : 'decreased'} by ${Random().nextInt(20) + 5}% compared to last month.',
      });
    }

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [accentColor, primaryColor],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.lightbulb_outline, color: Colors.white),
                    const SizedBox(width: 8),
                    Text(
                      'Financial Insights',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                if (insights.isNotEmpty) ...[
                  const Text(
                    'Here are some insights about your spending habits:',
                    style: TextStyle(color: Colors.white70),
                  ),
                ] else ...[
                  const Text(
                    'Not enough data to generate insights. Add more transactions.',
                    style: TextStyle(color: Colors.white),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 24),

          if (insights.isNotEmpty) ...[
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: insights.length,
              itemBuilder: (context, index) {
                final insight = insights[index];

                if (insight['type'] == 'budget') {
                  final category = insight['category'];
                  final percentage = insight['percentage'];

                  return Card(
                    margin: const EdgeInsets.only(bottom: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(8),
                                decoration: BoxDecoration(
                                  color: category.color.withOpacity(0.2),
                                  shape: BoxShape.circle,
                                ),
                                child: Icon(
                                  category.icon,
                                  color: category.color,
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      category.name,
                                      style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      'You\'ve spent ${percentage}% of your budget',
                                      style: TextStyle(
                                        fontSize: 14,
                                        color: Colors.grey.shade600,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              CircularProgressIndicator(
                                value: percentage / 100,
                                backgroundColor: Colors.grey.shade200,
                                valueColor: AlwaysStoppedAnimation<Color>(
                                  percentage > 80
                                      ? Colors.red
                                      : percentage > 60
                                      ? Colors.orange
                                      : Colors.green,
                                ),
                                strokeWidth: 8,
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          LinearProgressIndicator(
                            value: percentage / 100,
                            backgroundColor: Colors.grey.shade200,
                            valueColor: AlwaysStoppedAnimation<Color>(
                              percentage > 80
                                  ? Colors.red
                                  : percentage > 60
                                  ? Colors.orange
                                  : Colors.green,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            percentage > 80
                                ? 'Warning: You\'re close to exceeding your budget!'
                                : percentage > 60
                                ? 'You still have some budget left, but be careful.'
                                : 'You\'re doing well with your budget.',
                            style: TextStyle(
                              fontSize: 12,
                              color:
                                  percentage > 80
                                      ? Colors.red
                                      : percentage > 60
                                      ? Colors.orange
                                      : Colors.green,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                } else {
                  // Other insight types
                  IconData insightIcon;
                  Color insightColor;

                  if (insight['type'] == 'saving') {
                    insightIcon = Icons.savings;
                    insightColor = Colors.green;
                  } else {
                    insightIcon = Icons.trending_up;
                    insightColor = accentColor;
                  }

                  return Card(
                    margin: const EdgeInsets.only(bottom: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: insightColor.withOpacity(0.2),
                              shape: BoxShape.circle,
                            ),
                            child: Icon(insightIcon, color: insightColor),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              insight['message'],
                              style: const TextStyle(fontSize: 14),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }
              },
            ),
          ] else ...[
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.lightbulb_outline,
                    size: 64,
                    color: Colors.grey.shade300,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'No insights available yet',
                    style: TextStyle(color: Colors.grey.shade600, fontSize: 16),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Add more transactions to get personalized insights',
                    style: TextStyle(color: Colors.grey.shade500, fontSize: 14),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildStockRecommendations() {
    // Mock stock data
    final stocks = [
      {
        'symbol': 'BBCA',
        'name': 'Bank Central Asia',
        'price': 9450.0,
        'change': 2.5,
        'recommendation': 'Buy',
        'reason': 'Matches your risk profile and financial goals',
      },
      {
        'symbol': 'TLKM',
        'name': 'Telkom Indonesia',
        'price': 3850.0,
        'change': 1.2,
        'recommendation': 'Hold',
        'reason': 'Stable dividend payer',
      },
      {
        'symbol': 'ASII',
        'name': 'Astra International',
        'price': 5725.0,
        'change': -0.8,
        'recommendation': 'Buy',
        'reason': 'Undervalued based on your spending patterns',
      },
      {
        'symbol': 'UNVR',
        'name': 'Unilever Indonesia',
        'price': 4560.0,
        'change': 0.5,
        'recommendation': 'Hold',
        'reason': 'Consistent with your consumer spending',
      },
      {
        'symbol': 'ICBP',
        'name': 'Indofood CBP',
        'price': 8725.0,
        'change': 1.8,
        'recommendation': 'Buy',
        'reason': 'Aligns with your food expenditure patterns',
      },
    ];

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [primaryColor, Colors.deepPurple],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.trending_up, color: Colors.white),
                    const SizedBox(width: 8),
                    Text(
                      'Stock Recommendations',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                const Text(
                  'Based on your financial profile and spending habits, here are some stock recommendations:',
                  style: TextStyle(color: Colors.white70),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          Text(
            'Personalized Stock Picks',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: secondaryColor,
              fontSize: 16,
            ),
          ),
          const SizedBox(height: 16),

          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: stocks.length,
            itemBuilder: (context, index) {
              final stock = stocks[index];
              final isPositive = (stock['change'] as double) >= 0;

              return Card(
                margin: const EdgeInsets.only(bottom: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color: primaryColor,
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              stock['symbol'] as String,
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              stock['name'] as String,
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color:
                                  stock['recommendation'] == 'Buy'
                                      ? Colors.green.withOpacity(0.2)
                                      : Colors.orange.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              stock['recommendation'] as String,
                              style: TextStyle(
                                color:
                                    stock['recommendation'] == 'Buy'
                                        ? Colors.green
                                        : Colors.orange,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Text(
                            NumberFormat.currency(
                              locale: 'id',
                              symbol: 'Rp ',
                              decimalDigits: 0,
                            ).format(stock['price']),
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 6,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color:
                                  isPositive
                                      ? Colors.green.withOpacity(0.2)
                                      : Colors.red.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Row(
                              children: [
                                Icon(
                                  isPositive
                                      ? Icons.arrow_upward
                                      : Icons.arrow_downward,
                                  color: isPositive ? Colors.green : Colors.red,
                                  size: 12,
                                ),
                                const SizedBox(width: 2),
                                Text(
                                  '${isPositive ? '+' : ''}${stock['change']}%',
                                  style: TextStyle(
                                    color:
                                        isPositive ? Colors.green : Colors.red,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Why: ${stock['reason']}',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey.shade600,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),

          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: backgroundColor,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: accentColor.withOpacity(0.3)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.info_outline, color: accentColor),
                    const SizedBox(width: 8),
                    Text(
                      'Disclaimer',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: primaryColor,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                const Text(
                  'These recommendations are for informational purposes only and do not constitute investment advice. Past performance is not indicative of future results. Always do your own research before investing.',
                  style: TextStyle(fontSize: 12),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showAIResponse(BuildContext context) {
    showDialog(
      context: context,
      builder:
          (ctx) => AlertDialog(
            title: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: accentColor.withOpacity(0.2),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(Icons.smart_toy, color: accentColor),
                ),
                const SizedBox(width: 8),
                const Text('AI Response'),
              ],
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Based on your financial data, I can see that:',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: secondaryColor,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  '• Your highest spending category is Food\n'
                  '• You could save about 15% by cooking at home more\n'
                  '• Your current savings rate is approximately 20% of income\n'
                  '• Consider increasing emergency fund contributions',
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(ctx).pop();
                },
                child: const Text('Thanks!'),
              ),
            ],
          ),
    );
  }
}
